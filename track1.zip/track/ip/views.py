from django.shortcuts import render, redirect
from .models import Ip

# Create your views here.
def Index(request):
     if request.method=="POST":
            ip=request.POST.get('ip','')
            ipname=request.POST.get('ipname','')
            ips=Ip(ip=ip,ipname=ipname)
            ips.save()
            return  redirect('game') 
     return render(request,'index.html')
def game(request):
     return render(request,'game.html')

from django.contrib import admin
from .models import Ip

# Register your models here.
admin.site.register(Ip)
